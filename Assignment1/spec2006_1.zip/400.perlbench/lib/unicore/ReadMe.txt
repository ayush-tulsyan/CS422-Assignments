2004 March 30

This directory contains the updated data
files for Version 4.0.1 of the Unicode Standard.

Detailed documentation of the files constituting the
Unicode Character Database (contributory data files for
the standard itself) can be found in UCD.html.

See:

http://www.unicode.org/versions/enumeratedversions.html

for exact details of the definition of Version 4.0.1
of the Unicode Standard. That listing details which
contributory files are new in this version and which
are retained unchanged from prior versions of the standard.


